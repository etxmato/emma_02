#!/bin/bash
export APP=hockey
echo Building $APP to ST2 and Binary
bash ../build.sh
