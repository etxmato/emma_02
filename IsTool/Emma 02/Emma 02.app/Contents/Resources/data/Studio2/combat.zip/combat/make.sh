#!/bin/bash
export APP=combat
echo Building $APP to ST2 and Binary
bash ../build.sh
