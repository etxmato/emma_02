#!/bin/bash
export APP=berzerk
echo Building $APP to ST2 and Binary
bash ../build.sh
