#!/bin/bash
export APP=scramble
echo Building $APP to ST2 and Binary
bash ../build.sh
