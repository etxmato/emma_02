#!/bin/bash
export APP=pacman
echo Building $APP to ST2 and Binary
bash ../build.sh
