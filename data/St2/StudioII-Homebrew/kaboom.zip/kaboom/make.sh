#!/bin/bash
export APP=kaboom
echo Building $APP to ST2 and Binary
bash ../build.sh
