rm *.tar.gz *.zip
python2 makest2.py
zip kaboom.zip * 
